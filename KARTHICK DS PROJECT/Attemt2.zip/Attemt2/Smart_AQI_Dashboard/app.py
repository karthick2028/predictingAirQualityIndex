from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import pandas as pd
import os
import joblib
import matplotlib.pyplot as plt
import sqlite3
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this in production

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect(os.path.join(app.root_path, 'database.db'))
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, password FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return User(user[0], user[1], user[2])
    return None

def get_aqi_category(aqi):
    if aqi <= 50:
        return 'Good', 'green'
    elif aqi <= 100:
        return 'Moderate', 'yellow'
    elif aqi <= 150:
        return 'Poor', 'orange'
    elif aqi <= 200:
        return 'Very Poor', 'red'
    else:
        return 'Hazardous', 'purple'

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect(os.path.join(app.root_path, 'database.db'))
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, password FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        conn.close()
        if user and check_password_hash(user[2], password):
            user_obj = User(user[0], user[1], user[2])
            login_user(user_obj)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Load uploaded data if exists
    data_file = os.path.join(app.root_path, 'uploads', 'synthetic_data.csv')  # Default to synthetic
    if os.path.exists(os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')):
        data_file = os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')
    if os.path.exists(data_file):
        data = pd.read_csv(data_file)
        total_records = len(data)
        if 'AQI' in data.columns:
            avg_aqi = data['AQI'].mean()
            unhealthy_days = len(data[data['AQI'] > 100])
        else:
            avg_aqi = 0
            unhealthy_days = 0
    else:
        total_records = 0
        avg_aqi = 0
        unhealthy_days = 0
    return render_template('dashboard.html', total_records=total_records, avg_aqi=round(avg_aqi, 2), unhealthy_days=unhealthy_days)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith('.csv'):
            # Save the file directly without validation
            file.save(os.path.join(app.root_path, 'uploads', 'uploaded_data.csv'))
            flash('File uploaded successfully!')
            return redirect(url_for('dashboard'))
        else:
            flash('Please upload a valid CSV file.')
    return render_template('upload.html')

@app.route('/raw')
@login_required
def raw():
    data_file = os.path.join(app.root_path, 'uploads', 'synthetic_data.csv')
    if os.path.exists(os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')):
        data_file = os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')
    if os.path.exists(data_file):
        data = pd.read_csv(data_file)
        table_html = data.to_html(classes='table table-striped', index=False)
    else:
        table_html = '<p>No data available.</p>'
    return render_template('raw.html', table=table_html)

@app.route('/insights')
@login_required
def insights():
    data_file = os.path.join(app.root_path, 'uploads', 'synthetic_data.csv')
    if os.path.exists(os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')):
        data_file = os.path.join(app.root_path, 'uploads', 'uploaded_data.csv')
    if os.path.exists(data_file):
        data = pd.read_csv(data_file)
        pie_img = None
        bar_img = None
        trend_img = None

        # Pie chart for AQI categories if AQI column exists
        if 'AQI' in data.columns:
            categories = data['AQI'].apply(lambda x: get_aqi_category(x)[0])
            category_counts = categories.value_counts()
            plt.figure(figsize=(6,6))
            category_counts.plot.pie(autopct='%1.1f%%')
            plt.title('AQI Category Distribution')
            plt.savefig(os.path.join(app.root_path, 'static', 'pie_chart.png'))
            plt.close()
            pie_img = 'pie_chart.png'

        # Bar chart for pollutants if any pollutant columns exist
        pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'CO', 'O3']
        available_pollutants = [p for p in pollutants if p in data.columns]
        if available_pollutants:
            avg_pollutants = data[available_pollutants].mean()
            plt.figure(figsize=(8,5))
            avg_pollutants.plot.bar()
            plt.title('Average Pollutant Levels')
            plt.ylabel('Concentration')
            plt.savefig(os.path.join(app.root_path, 'static', 'bar_chart.png'))
            plt.close()
            bar_img = 'bar_chart.png'

        # Trend line if Date and AQI columns exist
        if 'Date' in data.columns and 'AQI' in data.columns:
            data['Date'] = pd.to_datetime(data['Date'])
            data = data.sort_values('Date')
            plt.figure(figsize=(10,5))
            plt.plot(data['Date'], data['AQI'])
            plt.title('AQI Trend Over Time')
            plt.xlabel('Date')
            plt.ylabel('AQI')
            plt.savefig(os.path.join(app.root_path, 'static', 'trend_chart.png'))
            plt.close()
            trend_img = 'trend_chart.png'

        return render_template('insights.html', pie_img=pie_img, bar_img=bar_img, trend_img=trend_img)
    else:
        return render_template('insights.html', pie_img=None, bar_img=None, trend_img=None)

@app.route('/tools', methods=['GET', 'POST'])
@login_required
def tools():
    if request.method == 'POST':
        pm25 = float(request.form['pm25'])
        pm10 = float(request.form['pm10'])
        no2 = float(request.form['no2'])
        so2 = float(request.form['so2'])
        co = float(request.form['co'])
        o3 = float(request.form['o3'])
        model = joblib.load(os.path.join(app.root_path, 'model.pkl'))
        prediction = model.predict([[pm25, pm10, no2, so2, co, o3]])[0]
        category, color = get_aqi_category(prediction)
        return render_template('tools.html', prediction=round(prediction, 2), category=category, color=color)
    return render_template('tools.html')

if __name__ == '__main__':
    app.run(debug=True)
