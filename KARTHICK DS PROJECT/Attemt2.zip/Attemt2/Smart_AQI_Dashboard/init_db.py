import sqlite3
import os
from werkzeug.security import generate_password_hash

def init_db():
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), 'database.db'))
    cursor = conn.cursor()
    cursor.execute('DROP TABLE IF EXISTS users')
    cursor.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    # Insert default user with hashed password
    hashed_password = generate_password_hash('password')
    cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', ('admin', hashed_password))
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized.")
